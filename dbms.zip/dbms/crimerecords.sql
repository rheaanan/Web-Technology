/*
Crime(RefId,Date,Area,Time,Type,I_Id) 
Investigating Officer(I_Id,Fname,LName,Area)
Victim(PId,FName,LName,Sex,PhNo,Address,Loss)	//casualties/injuries?
Criminal(criminalId,FName,LName,Sex,Age,JailNo)
Jail(JailId,Name,Area,Capacity)
Jailor(JailId,FName,LName)
Lawyer(PId,FName,LName,Firm) //seniority??
CourtCase(CaseId,RefId,Judge,Court,Status)	//status can be resolved/pending
Committed(RefId,criminalId)
Affected(RefId,PId)
HandledBy(PId,CaseId)

CREATE DATABASE criminalrecords;
*/
CREATE TABLE Crime(RefId char(10),Cdate date,Area varchar(15),Time char(5),Type varchar(30),I_Id char(10), 
					primary key(RefId));
CREATE TABLE Investigating_Officer(I_Id char(10),Fname varchar(30),LName varchar(30),Jurisdiction varchar(30),
					primary key(I_Id));

CREATE TABLE Victim(PId char(10),FName varchar(30),LName varchar(30),Sex char(1),PhNo varchar(15),Address varchar(100),Loss int,
					primary key(PId));
					
CREATE TABLE Jail(JailId char(10),Name varchar(25),Area varchar(15),Capacity int,
					primary key(JailId));

CREATE TABLE Criminal(criminalId char(10),FName varchar(30),LName varchar(30),Sex char(1),Age int,JailId char(10),
					primary key(criminalId),
					foreign key(JailId) references Jail on delete cascade);

CREATE TABLE Jailor(JailId char(10),FName varchar(30),LName varchar(30),
					primary key(JailId,Fname,Lname),
					foreign key(JailId) references Jail on delete cascade);

CREATE TABLE Lawyer(PId char(10),FName varchar(30),LName varchar(30),Firm varchar(25),
					primary key(PId));

CREATE TABLE CourtCase(CaseId char(10),RefId char(10),Judge varchar(50),Court varchar(30) ,Status varchar(15),
					primary key(CaseId),
					foreign key(RefId) references Crime on delete cascade);

CREATE TABLE Committed(RefId char(10),criminalId char(10),
					primary key(RefId),
					foreign key(RefId) references Crime on delete cascade,
					foreign key(criminalId) references Criminal on delete cascade);

CREATE TABLE Affected(RefId char(10),PId char(10),
					primary key(RefId),
					foreign key(RefId) references Crime on delete cascade,
					foreign key(PId) references Victim on delete cascade);

CREATE TABLE HandledBy(PId char(10),CaseId char(10),
					primary key(PId,CaseId),
					foreign key(PId) references Lawyer on delete cascade,
					foreign key(CaseId) references CourtCase on delete cascade);
					
insert into crime values('2016KA1234','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1111','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA2222','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA3333','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA4444','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1231','01/02/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1232','01/02/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1233','01/02/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1244','01/03/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1243','01/04/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1242','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1241','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1245','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1256','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1267','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1278','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1298','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1010','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1011','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1100','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1101','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1120','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1001','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1000','01/01/2016','Bannerghatta','12:30','murder','1234567890');
insert into crime values('2016KA1345','01/01/2016','Bannerghatta','12:30','murder','1234567890');


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Simple Personal</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen, projection, tv" />
<link rel="stylesheet" href="css/style-print.css" type="text/css" media="print" />
</head>
<body>
<div id="wrapper">
  <div class="title">
    <div class="title-top">
      <div class="title-left">
        <div class="title-right">
          <div class="title-bottom">
            <div class="title-top-left">
              <div class="title-bottom-left">
                <div class="title-top-right">
                  <div class="title-bottom-right">
                    <h1><a href="http://all-free-download.com/free-website-templates/">Criminal <span>Database</span> WEBSITE</a></h1>
                    <p>website to analyse criminal acitivities&hellip;</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <hr class="noscreen" />
  <div class="content">
    <div class="column-left">
      <h3>MENU</h3>
      <a href="#skip-menu" class="hidden">Skip menu</a>
      <ul class="menu">
        <li><a href="index.html" class="active">Home</a></li>
        <li><a href="quieries.html">Quieries</a></li>
        <li><a href="http://all-free-download.com/free-website-templates/">Portfolio</a></li>
        <li class="last"><a href="contact.html">Contact</a></li>
      </ul>
    </div>
    <div id="skip-menu"></div>
    <div class="column-right">
      <div class="box">
        <div class="box-top"></div>
        <div class="box-in">
          <h2>This is the queries page</h2>
          <p>please enter your query.</p>
		  <text value="q"> your query here</text>
		  

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(q=="crimes in bannerghatta")
{
$sql = "select RefId,Type from Crime 
	where Area='Bannerghatta'";

if(q=="no. female victims")
{
$sql ="select count(*) from Victim 
	where Sex='F';" ;
}
if(q=="crime rate")
{
$sql ="select count(*) from Criminal
	where Age<18;" ;
}
if(q=="crime rate")
{
$sql ="select Fname,Lname,Loss from Victim
	where Loss>20,000;" ;
}
if(q=="crime rate")
{
$sql ="select Criminal.criminalId,Fname,Lname,Crime.Type from Crime,Committed,Criminal
	where Crime.Type='murder' 
	and Crime.RefId=Committed.RefId
	and Committed.criminalId=Criminal.criminalId;" ;
}


if ($conn->query($sql) === TRUE) {
    echo "Table criminas created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
          <p>..</br>..</br>..</br>..</br>..</br> loaded!</p>
          <br />
          <h2>kind of queries we provide  </h2>
          <ul class="main-list">
            <li>Mauris viverra, <strong>tellus sed euismod</strong> auctor</li>
            <li>Cras <strong>condimentum</strong>, sapien et ultrices</li>
            <li>Pellentesque habitant <strong>morbi tristique</strong> senectus</li>
            <li>Nam rutrum, <strong>turpis sed ornare</strong></li>
            <li>Praesent <strong>feugiat</strong>, libero eget tincidunt</li>
          </ul>
        </div>
      </div>
      <div class="box-bottom">
        <hr class="noscreen" />
        <div class="footer-info-left"><a href="http://all-free-download.com/free-website-templates/">My personal website</a>, 2008. All rights reserved.</div>
        <div class="footer-info-right"><a href="http://www.mantisatemplates.com/">Mantis-a templates</a></div> 
      </div>
    </div>
    <div class="cleaner">&nbsp;</div>
  </div>
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div>
</body>
</html>
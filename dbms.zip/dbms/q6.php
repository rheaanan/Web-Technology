Diplaying Crimnals Of an Age group
<?php
	ob_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Crime Database</title>
		
		<link rel="" />
		<link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed-with-address-and-phones.css">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">


		<style type="text/css">
			.div1{
				width:80%;
				position:absolute;
				top:8%;
				left:10%;
				padding:10px;
				border:3px solid orange;
				border-radius: 25px;
			}
			
			h3, label{
			color: rgb(102, 0, 255)
			}
		
              
		</style>
		
	</head>

	<body>
<center><b><a href="index.html"><h1><span style="color:Orange;">>Crime</span> Database</h1></a></b></center>
<br>
<br>
<br>
<br><br><br><br><br>
<div class="div1">
<?php
extract($_GET);

	//Make sure some ISBN is sent

	
		$conn = mysqli_connect("localhost","root","");
		if(!$conn)
		{
			die("Could not establish connection to MYSQL");
		}
		else
		{
			$db=mysqli_select_db($conn,"CRIMINAL_RECORDS");
			$sql="SELECT criminalId ,FName,LName,Age from criminal where Age>'$low' and Age<'$up';";

			if(!$db)
			{
				
				die("Cannot connect to DB".mysql_error());
			}
			else
			{
			$results=mysqli_query( $conn,$sql);
				if(!$results)
				{
				die("Cannot get data".mysql_error());
				}
				else if ($results->num_rows == 0)
				{
						echo "<center>sorry :p  no Results </center> ";
				}
				else 
				{
					//echo $results;
					echo "<center><table border='2' cellspacing='2' cellpadding='6'>";
					echo "<tr style='background-color:grey;'><th>First Name</th><th>Last Name</th><th>Age</th>";
					while($row = $results->fetch_assoc())
					{
					
						echo "<tr>";
						echo "<td>" . $row['FName'] . "</td>";	
						echo "<td>" . $row['LName'] . "</td>";	
						echo "<td>" . $row['Age'] . "</td>";	
						
						echo "</tr>";						
					}
					echo "</table></center>";
				}
			}
		}
	
			
		//conn.close();	

ob_flush();
flush();
?>
<hr>
</div>
<br><br><br><br><br>
<br><br><br><br><br>
<br><br><br><br><br>


		<footer class="footer-distributed">

			<div class="footer-left">

				<h3>Criminal<span style="color:orange">Database</span></h3>

				<p class="footer-links">
					<a href="#">Home  </a>
					
					<a href="#">About Us  </a>
					
					<a href="#">Faq  </a>
					
					<a href="#">Contact Us</a>
				</p>

				<p class="footer-company-name">CrimeRecords</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Electronic City, </span> Bangalore,Karnataka</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+1 555 123456</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">support@crimes.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Us</span>
					We Provide Information on Criminals 
				</p>

				<div class="footer-icons">

					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
					<a href="#"><i class="fa fa-github"></i></a>

				</div>

			</div>

		</footer>
	</body>
</html>
	